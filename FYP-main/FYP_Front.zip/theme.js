import {DefaultTheme, configureFonts} from 'react-native-paper';

export const theme = {
    ...DefaultTheme,
    white:"white"
};
export default theme;
