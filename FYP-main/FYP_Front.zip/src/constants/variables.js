export const variables = {
    // baseUrl: 'http://192.168.0.102:3400',
    baseUrl: 'https://api.entercosmos.space',
    defaultUserAge: 30,
    callDuration:1,
};
