import theme from '../../theme';

export default {
    bgWhite: {
        backgroundColor: theme.colors.white,
    },
};
